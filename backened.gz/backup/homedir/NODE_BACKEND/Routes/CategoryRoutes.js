const express = require("express");
const auth = require("../config/auth");
const router = express.Router();

const {
  categoryValiations,
  createCategory,
  fetchAllCategory,
  fetchSingleCategory,
  updateCategory,
  deleteCategory,
} = require("../Controllers/CategoryController");

router.post("/", categoryValiations, createCategory);
router.get("/", fetchAllCategory);
router.get("/:id", fetchSingleCategory);
router.put("/:id", updateCategory);
router.delete("/:id", deleteCategory);

module.exports = router;
