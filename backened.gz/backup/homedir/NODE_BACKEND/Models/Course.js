const db = require("../config/db");
class COURSE {
  constructor(
    category_id,
    course_title,
    short_description,
    estimated_time,
    course_type,
    course_details,
    image,
    preview_video,
  ) {
    this.category_id = category_id;
    this.course_title = course_title;
    this.short_description = short_description;
    this.estimated_time = estimated_time;
    this.course_type = course_type;
    this.course_details = course_details;
    this.image = image;
    this.preview_video = preview_video;
  }
  create() {
    let createSql = `insert into course (category_id,course_title,short_description,estimated_time,course_type,course_details,image,preview_video) 
    values ('${this.category_id}','${this.course_title}','${this.short_description}','${this.estimated_time}',
    '${this.course_type}','${this.course_details}','${this.image}','${this.preview_video}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM course;";
    return db.execute(sql);
  }
  // fetch course based on category search
  static fetchCourseOnCategory(category) {
    let sql = `SELECT id,course_title,
                estimated_time,
                course_type,
                image
                FROM course
                WHERE category_id='${category}' ORDER BY id DESC`;

    return db.execute(sql);
  }
  
  static findById(id) {
    return db.execute(`SELECT * FROM course WHERE ID=${id}`);
  }
  
  static fetchSingleCourseOnFirstSubContent(id){
      return db.execute(`SELECT course.course_title,course.short_description,course.image,content_sub_section.id,content_sub_section.sub_section_title,content_sub_section.course_id FROM course INNER JOIN content_sub_section ON content_sub_section.course_id=course.id WHERE course.id='${id}' ORDER BY content_sub_section.id ASC LIMIT 1`);
  }

static fetchCoursesOnUser(id){
    return db.execute(`SELECT course.course_title,course.image,enrolled_courses.redirection_link,enrolled_courses.course_id,enrolled_courses.id,course_category.category FROM course LEFT JOIN enrolled_courses ON enrolled_courses.course_id=course.id INNER JOIN course_category ON course.category_id=course_category.id WHERE enrolled_courses.user_id='${id}'`)
}
  updateCourse(id) {
    let updateSql = `UPDATE course SET course_title='${this.course_title}', short_description='${this.short_description}', estimated_time='${this.estimated_time}', course_type='${this.course_type}', course_details='${this.course_details}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteCourse(id) {
    return db.execute(`DELETE FROM course where id='${id}'`);
  }
}
module.exports = COURSE;
