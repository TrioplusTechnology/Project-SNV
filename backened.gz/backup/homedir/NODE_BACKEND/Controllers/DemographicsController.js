const DEMOGRAPHICS = require("../Models/Demographics");
const { body, validationResult } = require("express-validator");

exports.demographicsValiations = [
  body("gender").not().isEmpty().trim().withMessage("Gender is required"),
  body("age").not().isEmpty().trim().withMessage("Age is required"),
  body("district").not().isEmpty().trim().withMessage("District is required"),

];

exports.createDemographics = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    const { user_sub_id,gender,age,district,registration_date } = req.body;
    let c_Demographics = new DEMOGRAPHICS(user_sub_id,gender,age,district,registration_date);
    result = await c_Demographics.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Demographics data has been added successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while adding demographics data !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllDemographics = async (req, res, next) => {
  try {
    const [demographics] = await DEMOGRAPHICS.fetchAll();
    res.status(200).json(demographics.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleDemographics = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [demographics] = await DEMOGRAPHICS.findById(id);
    res.status(200).json(demographics);
  } catch (error) {
    next(error);
  }
};

exports.updateDemographics = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { user_sub_id,gender,age,district } = req.body;
    let u_demographics = new DEMOGRAPHICS(user_sub_id,gender,age,district);
    result = await u_demographics.updateUserDemographics(id);
    if (result[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Demographics Data has been updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating demographics data",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteDemographics = async (req, res, next) => {
  try {
    const id = req.params.id;
    let d_demographics = new DEMOGRAPHICS(null);
    result = await d_demographics.deleteDemographics(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Demographics data has been deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting demographics data",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
