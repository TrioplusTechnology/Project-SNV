const db = require("../config/db");
class LOGIN {
  constructor(username,password) {
    this.username = username;
    this.password=password;
  }
  create() {
    let createSql = `insert into login (username, password) 
    values ('${this.username}','${this.password}')`;
    return db.execute(createSql);
  }

  static login(id) {
    let findSql = `SELECT * FROM login WHERE id='${id}'`;
    return db.execute(findSql);
  }

  static fetchAll() {
    let sql = "SELECT * FROM login;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM login WHERE id='${id}'`);
  }

  findUser(email) {
    return db.execute(`SELECT * FROM login WHERE username='${email}' `);
  }
  
  deleteCourse(id) {
    return db.execute(`DELETE FROM login where id='${id}'`);
  }
}
module.exports = LOGIN;
