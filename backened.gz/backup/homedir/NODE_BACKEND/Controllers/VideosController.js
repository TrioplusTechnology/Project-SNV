const VIDEOS = require("../Models/Videos");
const { body, validationResult } = require("express-validator");

exports.videoValiations = [
  body("title").not().isEmpty().trim().withMessage("title is required"),
  body("link").not().isEmpty().trim().withMessage("link is required"),
];

exports.createVideos = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    const { title, duration, link } = req.body;
    const thumbnail = `${process.env.APP_HOSTING_ADDRESS + req.file.filename}`;

    let c_Videos = new VIDEOS(thumbnail, title, duration, link);
    result = await c_Videos.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Video has been created successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while creating Video !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllVideos = async (req, res, next) => {
  try {
    const [videos] = await VIDEOS.fetchAll();
    res.status(200).json(videos.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleVideos = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [video] = await VIDEOS.findById(id);
    res.status(200).json(video);
  } catch (error) {
    next(error);
  }
};

exports.updateVideos = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { title, link, duration } = req.body;
    let thumbnail = "noull";
    let u_videos = new VIDEOS(thumbnail, title, link, duration);
    result = await u_videos.updateVideos(id);
    if (result[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Video updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating videos",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteVideos = async (req, res, next) => {
  try {
    const id = req.params.id;
    let {thumbnail}=req.body;
    fs.unlink(`./course_uploads/${thumbnail.split("/")[4]}`, function (err) {
      if (err) throw err;
      // if no error, file has been deleted successfully
      console.log("File deleted!");
    });


    let d_videos = new VIDEOS(null);
    result = await d_videos.deleteVideos(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Video has been deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting video !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
