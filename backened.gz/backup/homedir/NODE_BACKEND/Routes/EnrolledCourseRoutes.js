const express = require("express");
const auth = require("../config/auth");
const router = express.Router();

const {
  enrolledValiations,
  createEnrolled,
  fetchAllEnrolled,
  fetchSingleEnrolled,
  updateRedirection,
  deleteEnrolled,
  fetchSingleEnrolledOnCourse,
   fetchSingleEnrolledOnUser
  
} = require("../Controllers/EnrolledCourseController");

router.post("/", enrolledValiations, createEnrolled);
router.get("/", fetchAllEnrolled);
router.get("/:id", fetchSingleEnrolled);
router.put("/:id", updateRedirection);
router.delete("/:id", deleteEnrolled);

router.get('/onCourse/:id',fetchSingleEnrolledOnCourse);
router.get('/onUser/:id',fetchSingleEnrolledOnUser);


module.exports = router;
