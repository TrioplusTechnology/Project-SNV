import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  course_id: "",
};

export const courseInfoSlice = createSlice({
  name: "course",
  initialState,
  reducers: {
    createCourse: (state, { payload }) => {
      state.course_id = payload;
    },
  },
});

export const { createCourse } = courseInfoSlice.actions;
export default courseInfoSlice.reducer;
