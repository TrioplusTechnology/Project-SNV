const INSTRUCTOR = require("../Models/Instructor");
const fs = require("fs");

exports.createInstructor = async (req, res, next) => {
  try {
    const { course_id, name, position, details } = req.body;
    const image = `${process.env.APP_HOSTING_ADDRESS + req.file.filename}`;

    let c_Instructor = new INSTRUCTOR(
      course_id,
      name,
      position,
      details,
      image,
    );
    result = await c_Instructor.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Instructor has been added successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while adding instructor !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllInstructor = async (req, res, next) => {
  try {
    const [categories] = await INSTRUCTOR.fetchAll();
    res.status(200).json(categories.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchInstructorCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await INSTRUCTOR.fetchInstructorOnCourse(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleInstructor = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await INSTRUCTOR.findById(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.updateInstructor = async (req, res, next) => {
  try {
    const id = req.params.id;
    const { name, position, details } = req.body;

    let u_instructor = await INSTRUCTOR.updateInstructor(
      id,
      name,
      position,
      details,
    );
    if (u_instructor[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Instructor updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating Instructor",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteInstructor = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { image } = req.body;

    fs.unlink(`./instructor_uploads/${image.split("/")[4]}`, function (err) {
      if (err) throw err;
      // if no error, file has been deleted successfully
      console.log("File deleted!");
    });

    let d_instructor = new INSTRUCTOR(null);
    result = await d_instructor.deleteCourse(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Instructor deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting Instructor !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
