const express = require("express");
const router = express.Router();
const auth = require("../config/auth");



const {
  createProgress,
  fetchAllProgress,
  updateProgressCheck
} = require("../Controllers/ProgressController");

router.post('/',createProgress);
router.get('/user/:id',fetchAllProgress);
router.put('/update',updateProgressCheck)

module.exports = router;
