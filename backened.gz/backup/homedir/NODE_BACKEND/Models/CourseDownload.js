const db = require("../config/db");
class DOWNLOADS {
  constructor(course_id, download_file, downloads) {
    this.course_id = course_id;
    this.download_file = download_file;
    this.downloads = downloads;
   
  }
  create() {
    let createSql = `insert into Course_download (course_id,
        download_file,
        downloads
       ) 
    values ('${this.course_id}','${this.download_file}','${this.downloads}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT course.course_title,Course_download.id,Course_download.download_file,Course_download.downloads from Course_download INNER JOIN course on course.id=Course_download.course_id";
    return db.execute(sql);
  }
   static findById(id) {
     return db.execute(`SELECT * FROM Course_download WHERE course_id=${id}`);
   }

  static updateDownloads(id,downloads) {
    let updateSql = `UPDATE Course_download SET downloads='${downloads}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteCourseDownload(id) {
    return db.execute(`DELETE FROM Course_download where id='${id}'`);
  }
}
module.exports = DOWNLOADS;
