import React from 'react'

function CoursesTitle({course}) {
    return (
        <div className='my-4'>
            <h1 className="my-3">
                {course} Courses
            </h1>
        </div>
    )
}

export default CoursesTitle
