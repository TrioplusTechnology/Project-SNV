const express = require("express");
const router = express.Router();

// const {
//   register,
//   userLogin
// } = require("../Controllers/GoogleLoginController");
// // router.post("/register", register);
// // router.post("/login", userLogin);

module.exports = router;
