import axios from 'axios'
import React, { useCallback, useEffect } from 'react'
import { useState } from 'react'
import { useSelector } from 'react-redux'
import { Link, useHistory } from 'react-router-dom'
import MyLearningCard from '../components/Cards/MyLearningCard'
import MasterLoading from '../components/LoadingSpinners/MasterLoading'
import Page from '../templates/Page'


function Dashboard() {
    const user_id=useSelector(state=>state.user.user_id);
    const [data,setData]=useState([]);
    const [loading,setLoading]=useState(false);
    const [delt,setDelete]=useState(false)

   

    useCallback(
        () => {
            return setDelete(!delt)
        },
        [delt],
    )


    const history=useHistory();
    const handleLogout=()=>{
        localStorage.removeItem('token');
        history.push('/');
        window.location.reload(false);

    }

    useEffect(() => {
        const fetch=async()=>{
            try {
                setLoading(true)
                await axios.get(`${process.env.REACT_APP_URL}/course/onUser/${user_id}`).then(res=>{
                    console.log(res)
                    setData(res.data);
                    setLoading(false);
                })
            } catch (error) {
                console.error(error);
            }
        }
        fetch()
    }, [user_id,delt])
    return (
        <Page>
            <div className="container mx-auto px-4 px-8">
            <div className="my-4">
                        <h1>My Learning</h1>
                        <p>All the list of your subscribed courses</p>
                        <div className="flex items-center space-x-4">
                        <button className='btn-primary my-4 rounded-md' onClick={handleLogout}>Logout</button>
                        {/* <button className='rounded-md bg-blue-500 p-2 px-3 text-white' onClick={handleLogout}>Update Profile</button> */}
                        </div>
                    </div>
                <div className="lg:grid lg:grid-cols-4 lg:gap-8 my-8 h-full">
                    {loading&&<MasterLoading />}
                    {data.map(item=>(
                        <MyLearningCard id={item.id} img={item.image} title={item.course_title} category={item.category} progress='51' course_id={item.course_id} redirection_link={item.redirection_link} dlt={useCallback} />  
                    ))}
                    
                  
                   
                </div>
            </div>
        </Page>
    )
}

export default Dashboard
