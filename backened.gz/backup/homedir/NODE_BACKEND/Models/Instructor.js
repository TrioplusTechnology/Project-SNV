const db = require("../config/db");
class INSTRUCTOR {
  constructor(course_id, name, position, details, image) {
    this.course_id = course_id;
    this.name = name;
    this.position = position;
    this.details = details;
    this.image = image;
  }
  create() {
    let createSql = `insert into instructor (course_id,
        name,
        position,
        details,
        image) 
    values ('${this.course_id}','${this.name}','${this.position}','${this.details}',
    '${this.image}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM instructor;";
    return db.execute(sql);
  }
  
  static fetchInstructorOnCourse(id) {
    let sql = `SELECT * FROM instructor WHERE course_id='${id}';`;
    return db.execute(sql);
  }
  
  static findById(id) {
    return db.execute(`SELECT * FROM instructor WHERE ID=${id}`);
  }

  static updateInstructor(id, name, position, details) {
    let updateSql = `UPDATE instructor SET name='${name}', position='${position}', details='${details}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteCourse(id) {
    return db.execute(`DELETE FROM instructor where id='${id}'`);
  }
}
module.exports = INSTRUCTOR;
