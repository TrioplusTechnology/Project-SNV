const express = require("express");
const auth = require("../config/auth");
const router = express.Router();

const {
  reviewValiations,
  createReview,
  fetchAllReview,
  fetchAvgReviewOnCourse
} = require("../Controllers/ReviewController");

router.post("/", reviewValiations, createReview);
router.get("/:id", fetchAllReview);
router.get('/avg/:id',fetchAvgReviewOnCourse);

module.exports = router;
