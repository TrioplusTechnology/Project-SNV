const REVIEW = require("../Models/Review");
const { body, validationResult } = require("express-validator");

exports.reviewValiations = [
  body("review_message").not().isEmpty().trim().withMessage("review is required"),
];

exports.createReview = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    const { course_id,user_id,stars,review_message } = req.body;
    let c_Review = new REVIEW(course_id,user_id,stars,review_message);
    result = await c_Review.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Review has been created successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while creating review !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllReview = async (req, res, next) => {
  const id=req.params.id
  try {
    const [reviews] = await REVIEW.fetchAllReviewOnCourse(id);
    res.status(200).json(reviews);
  } catch (error) {
    next(error);
  }
};

exports.fetchAvgReviewOnCourse = async (req, res, next) => {
  const id=req.params.id
  try {
    const [reviews] = await REVIEW.fetchAvgRating(id);
    res.status(200).json(reviews);
  } catch (error) {
    next(error);
  }
};
