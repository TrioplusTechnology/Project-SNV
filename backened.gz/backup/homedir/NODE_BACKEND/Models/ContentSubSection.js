const db = require("../config/db");
class CONTENTSUBSECTION {
  constructor(
    course_id,
    section_id,
    sub_section_title,
    time,
    preview,
    text_content,
    YoutubeLink
  ) {
    this.course_id = course_id;
    this.section_id = section_id;
    this.sub_section_title = sub_section_title;
    this.time = time;
    this.preview = preview;
    this.text_content=text_content;
    this.YoutubeLink=YoutubeLink;
  }
  
//   here it used to be video and pdf upload but now it acts as a youtube video link
  
  create() {
    let createSql = `INSERT INTO content_sub_section  (
   course_id,
    section_id,
    sub_section_title,
    time,
    preview,
    text_content,
    YoutubeLink
    ) 
    values ('${this.course_id}','${this.section_id}','${this.sub_section_title}','${this.time}','${this.preview}','${this.text_content}','${this.YoutubeLink}')`;
    return db.execute(createSql);
  }

  static fetchAll() {
    let sql = "SELECT * FROM content_sub_section;";
    return db.execute(sql);
  }

  static findById(id) {
    return db.execute(`SELECT * FROM content_sub_section WHERE ID=${id}`);
  }
  
   static findBySectionId(id) {
    return db.execute(`SELECT * FROM content_sub_section WHERE section_id=${id}`);
  }
  
//   static findBySectionOnUser(id,enrolled_id){
//     return db.execute(`SELECT content_sub_section.id,content_sub_section.course_id,content_sub_section.section_id,content_sub_section.material_id, content_sub_section.sub_section_title,content_sub_section.time,content_sub_section.preview,content_sub_section.text_content,progress.checked  FROM content_sub_section left join progress on content_sub_section.id=progress.sub_content_id WHERE content_sub_section.section_id=${id} && progress.enrolled_id='${enrolled_id}'`);

//   }
  
//   static findSectionsLearningMaterial(id){
//       return db.execute(`SELECT content_sub_section.sub_section_title, learning_material.learning_material FROM content_sub_section INNER JOIN learning_material on content_sub_section.material_id=learning_material.id WHERE content_sub_section.id='${id}'`)
//   }

  static update(id, section_title, time, preview, text_content,YoutubeLink) {
    let updateSql = `UPDATE content_sub_section SET sub_section_title='${section_title}', time='${time}', preview='${preview}',text_content='${text_content}',YoutubeLink='${YoutubeLink}' where id='${id}';`;
    return db.execute(updateSql);
  }
  static delete (id) {
    return db.execute(`DELETE FROM content_sub_section where id='${id}'`);
  };
  

  

}
module.exports = CONTENTSUBSECTION;
