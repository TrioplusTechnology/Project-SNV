import React from 'react'
import AvgReview from './TabUtils/AvgReview'

function TabReviews() {
    return (
        <div>
            <h1>Review</h1>

            <AvgReview />
        </div>
    )
}

export default TabReviews
