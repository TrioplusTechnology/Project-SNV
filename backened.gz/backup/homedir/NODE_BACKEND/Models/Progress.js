const db = require("../config/db");
class PROGRESS {
  constructor(enrolled_id,sub_section_id,checked) {
    this.enrolled_id=enrolled_id;
    this.sub_section_id=sub_section_id;
    this.checked=checked;
  }
  create() {
    let createSql = `insert into progress (enrolled_id,sub_section_id,checked) values ('${this.enrolled_id}','${this.sub_section_id}','${this.checked}')`;
    return db.execute(createSql);
  }

  static fetchAllProgressOfUser(id){
      return db.execute(`select * from progress where enrolled_id='${id}' && checked='true'`)
  }
  
    static updateChecked(id,checked,enrolled_id){
      return db.execute(`update progress set checked='${checked}' where sub_section_id='${id}' && enrolled_id='${enrolled_id}'`)
  }
  
  
}
module.exports = PROGRESS;
