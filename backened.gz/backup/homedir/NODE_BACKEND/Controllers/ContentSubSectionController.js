const CONTENTSUBSECTION = require("../Models/ContentSubSection");
const fs = require("fs");

exports.createContentSubSection = async (req, res, next) => {
  try {
    const {course_id, section_id, sub_section_title, time, preview, text_content,YoutubeLink
    } = req.body;

    //   it used to be file upload for video but now it acts as youtube video link --> learningin material and pdf into youtube link text

    // let learning_material = `${
    //   process.env.APP_HOSTING_ADDRESS + req.file.filename
    // }`;

    let createContent = new CONTENTSUBSECTION(
      course_id,
      section_id,
      sub_section_title,
      time,
      preview,
      text_content,
      YoutubeLink
    );
   
     result = await createContent.create();
     if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Content has been added successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while uploading content !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error)
  }
};

exports.fetchAllContentSubSection = async (req, res, next) => {
  try {
    const [content_sub] = await CONTENTSUBSECTION.fetchAll();
    res.status(200).json(content_sub.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleContentSubSection = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await CONTENTSUBSECTION.findById(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleContentSubSectionOnSection = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await CONTENTSUBSECTION.findBySectionId(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

// exports.fetchLearningMaterialContentSubSection = async (req, res, next) => {
//   try {
//     const id = req.params.id;
//     const [course] = await CONTENTSUBSECTION.findSectionsLearningMaterial(id);
//     res.status(200).json(course);
//   } catch (error) {
//     next(error);
//   }
// };

exports.updateContentSubSection = async (req, res, next) => {
  try {
    const id = req.params.id;
    const {
      sub_section_title,
      time,
      preview,
      checked,
      text_content,
      YoutubeLink,
    } = req.body;

    result = await CONTENTSUBSECTION.update(
      id,
      sub_section_title,
      time,
      preview,
      checked,
      text_content,
      YoutubeLink,
    );
    if (result[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Course content --sub updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating Course content --sub",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteCourseContentSub = async (req, res, next) => {
  try {
    const { id } = req.body;

    result = await CONTENTSUBSECTION.delete(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "content sub section deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting content sub section !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
