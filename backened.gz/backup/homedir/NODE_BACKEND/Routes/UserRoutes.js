const express = require("express");
const router = express.Router();

const {
  registerValiations,
  register,
  userLogin,
  userLoginTwo,
  getUsers
} = require("../Controllers/UserController");
router.get("/", getUsers);
router.post("/register", register);
router.post("/login", userLogin);
router.post("/login/two",userLoginTwo);
//   router.put("/:id", userUpdate);

module.exports = router;
