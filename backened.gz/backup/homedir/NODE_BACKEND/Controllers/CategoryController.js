const CATEGORY = require("../Models/Category");
const { body, validationResult } = require("express-validator");

exports.categoryValiations = [
  body("category").not().isEmpty().trim().withMessage("category is required"),
];

exports.createCategory = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    const { category } = req.body;
    let c_Category = new CATEGORY(category);
    result = await c_Category.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Category has been created successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while creating category !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllCategory = async (req, res, next) => {
  try {
    const [categories] = await CATEGORY.fetchAll();
    res.status(200).json(categories.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleCategory = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [category] = await CATEGORY.findById(id);
    res.status(200).json(category);
  } catch (error) {
    next(error);
  }
};

exports.updateCategory = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { category } = req.body;
    let u_category = new CATEGORY(category);
    result = await u_category.updateCategory(id);
    if (result[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Category updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating category",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteCategory = async (req, res, next) => {
  try {
    const id = req.params.id;
    let d_category = new CATEGORY(null);
    result = await d_category.deleteCategory(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Category deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting category !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
