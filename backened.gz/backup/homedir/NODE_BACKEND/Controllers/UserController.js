const USER = require("../Models/User");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcrypt");

function generateAccessToken(user) {
  return jwt.sign(user, process.env.SECRET_KEY, { expiresIn: "100800s" });
}
exports.registerValiations = [
  body("username").not().isEmpty().trim().withMessage("username is required")
];

exports.register = async (req, res) => {
  const { user_id, user_email, username, image,password } = req.body;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
     // Hash password
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
  try {
    let admin_login = new USER(user_id, user_email, username, image,hash);
    
    logingin = await admin_login.create();
    // console.log("loggiiningin", logingin[0].affectedRows);
    const user={
        user_id,
        user_email,
        username,
        image,
        password
    }
    if (logingin.length >= 1) {
     const token = generateAccessToken(user);

      res.status(200).json({
        err: false,
        msg: "user created in successfully",
        token
        
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while registering your account",
      });
    }
  } catch (error) {
    return res.status(500).json({ errors: error });
  }
};

exports.getUsers = async (req, res, next) => {
  try {
    const [users] = await USER.fetchAll();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};
exports.userLogin = async (req, res, next) => {
  try {
    let { user_id } = req.body;
    // bycript

    const [user] = await USER.login(user_id);
    console.log(user.length);
    if (user.length >= 1) {
      const token = generateAccessToken(user[0]);
        return res
          .status(200)
          .json({ msg: "You have login successfully", token, user });
    } else {
      return res.status(404).json({ errors: [{ msg: "user not found" }] });
    }
  } catch (error) {
    next(error);
  }
};

exports.userLoginTwo = async (req, res, next) => {
    // res.status(200).json({msg:'sf'})
  try {
    let { email, password } = req.body;

    let [admin_login] = await USER.findUser(email);
    console.log(admin_login[0]);
    if (admin_login.length >= 1) {
      const matched = await bcrypt.compare(password, admin_login[0].PASSWORD);
      if (matched) {
        const token = generateAccessToken(admin_login[0]);
        return res
          .status(200)
          .json({ msg: "You have login successfully", token });
      } else {
        return res
          .status(401)
          .json({ errors: [{ msg: "Password is not correct" }] });
      }
    } else {
      return res.status(404).json({ errors: [{ msg: "user not found" }] });
    }
  } catch (error) {
    next(error);
  }
};
// exports.userUpdate = async (req, res, next) => {
//   try {
//     const id = req.params.id;
//     let { username, password } = req.body;
//     // Hash password
//     const salt = await bcrypt.genSalt(10);
//     const hash = await bcrypt.hash(password, salt);
//     let update = new Login(username, hash);
//     update = await update.updateAdmin(id);
//     if (update.length >= 1) {
//       res.status(200).json({
//         err: false,
//         msg: "Account Updated successfully",
//       });
//     } else {
//       res.status(401).json({
//         err: true,
//         msg: "Error while updating the user",
//       });
//     }
//   } catch (error) {
//     next(error);
//   }
// };
