const ENROLLED = require("../Models/EnrolledCourse");
const { body, validationResult } = require("express-validator");

exports.enrolledValiations = [
  body("redirection_link").not().isEmpty().trim().withMessage("redirection link is required"),
];

exports.createEnrolled = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
      
    const { user_id,course_id,redirection_link } = req.body;
    let c_Enrolled = new ENROLLED(user_id,course_id,redirection_link);
    result = await c_Enrolled.create();
    if (parseInt(result[0].affectedRows) === 1) {
    const [enrolled_id]=await ENROLLED.findLatestEnrolledCourse();
    const id=enrolled_id[0].id
    if(id!==null){
        const [createprogress]= await ENROLLED.createProgress(
          id,
          redirection_link
        );
    }
    
    
    res.status(200).json({
        id,
        err: false,
        msg: "Course has been successfully added to Enrolled list !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while adding course in enrolled list !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};


exports.fetchAllEnrolled = async (req, res, next) => {
  try {
    const [enrolled_courses] = await ENROLLED.fetchAll();
    res.status(200).json(enrolled_courses.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleEnrolled = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [enrolled] = await ENROLLED.findById(id);
    res.status(200).json(enrolled);
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleEnrolledOnCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [enrolled] = await ENROLLED.findByCourse(id);
    res.status(200).json(enrolled);
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleEnrolledOnUser = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [enrolled] = await ENROLLED.findByUser(id);
    res.status(200).json(enrolled);
  } catch (error) {
    next(error);
  }
};

exports.updateRedirection = async (req, res, next) => {
  try {
    const id = req.params.id;
    const { redirection_link } = req.body;

    let u_redirection = await ENROLLED.updateLink(
      id,
      redirection_link
    );
    if (u_redirection[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Link has been updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating Link",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteEnrolled = async (req, res, next) => {
  try {
    const id = req.params.id;
    let d_category = new ENROLLED(null);
    result = await d_category.deleteEnrolled(id);
    if (parseInt(result[0].affectedRows) === 1) {
      const [dlt_progress]=await ENROLLED.deleteProgress(id)
      res.status(200).json({
        err: false,
        msg: "Enrolled course data has been deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting enrolled course data !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
