const db = require("../config/db");
class STATISTICS {
  
  
  static fetchNoUsers() {
    let sql = "SELECT count(user_id) as no FROM users ;";
    return db.execute(sql);
  }
  
    static fetchNoCourses() {
    let sql = "SELECT count(id) as no FROM course ;";
    return db.execute(sql);
  }
  
   static fetchNoEnrolledCourses() {
    let sql = "SELECT count(id) as no FROM enrolled_courses ;";
    return db.execute(sql);
  }
  
   static fetchTotalContentNo(id) {
    let sql = `SELECT count(id) as no FROM content_sub_section where course_id='${id}'`;
    return db.execute(sql);
  }
  
}
module.exports = STATISTICS;
