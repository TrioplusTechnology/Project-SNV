const USER = require("../Models/User");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcrypt");
const { OAuth2Client }=require('google-auth-library');


function generateAccessToken(user) {
  return jwt.sign(user, process.env.SECRET_KEY, { expiresIn: "100800s" });
}


exports.register = async (req, res) => {
    const client=new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
    const {token}=req.body;
    const ticket=await client.verifyIdToken({
        idToken:token,
        audience:process.env.CLIENT_ID,
    });
    
  const { id, email, name, picture} = ticket.getPayload();
  const password=id;
  
     // Hash password
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
  try {
    let admin_login = new USER(id, email, name, picture,hash);
    
    logingin = await admin_login.create();
    // console.log("loggiiningin", logingin[0].affectedRows);
    const user={
      id, email, name, picture,hash
    }
    if (logingin.length >= 1) {
     const token = generateAccessToken(user);

      res.status(200).json({
        err: false,
        msg: "user created in successfully",
        token
        
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while registering your account",
      });
    }
  } catch (error) {
    return res.status(500).json({ errors: error });
  }
};


exports.userLogin = async (req, res, next) => {
  try {
      
    let { user_id } = req.body;
    // bycript

    const [user] = await USER.login(user_id);
    console.log(user.length);
    if (user.length >= 1) {
      const token = generateAccessToken(user[0]);
        return res
          .status(200)
          .json({ msg: "You have login successfully", token, user });
    } else {
      return res.status(404).json({ errors: [{ msg: "user not found" }] });
    }
  } catch (error) {
    next(error);
  }
};
