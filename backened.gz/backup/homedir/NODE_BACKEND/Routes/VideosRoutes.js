const express = require("express");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const auth = require("../config/auth");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "course_uploads");
  },
  filename: function (req, file, cb) {
    cb(
      null,
      file.fieldname + "_" + Date.now() + path.extname(file.originalname),
    );
  },
});
const upload = multer({ storage: storage });

const {
  createVideos,
  fetchAllVideos,
  fetchSingleVideos,
  updateVideos,
  deleteVideos,
} = require("../Controllers/VideosController");

router.post("/",upload.single('thumbnail'),createVideos);
router.get("/", fetchAllVideos);
router.get("/:id", fetchSingleVideos);
router.put("/:id", updateVideos);
router.delete("/:id", deleteVideos);

module.exports = router;
