import { BrowserRouter, HashRouter, Redirect, Route } from "react-router-dom";
import Home from "./pages/Home";
import "./css/master.scss";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Courses from "./pages/Courses";
import CoursesSearch from "./pages/CoursesSearch";
import CoursePreview from "./pages/CoursePreview";
import Dashboard from "./pages/Dashboard";
import SubscribedCourse from "./pages/SubscribedCourse";
import { useEffect, useState } from "react";
import jwtDecode from "jwt-decode";
import jwt from "jsonwebtoken";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { createUser } from "./Redux/user/UserSlice";
import StartCourse from "./pages/StartCourse";
import About from "./pages/About";
import Partners from "./pages/Partners";
import Demographics from "./pages/Demographics";
import Videos from "./pages/Videos";

function App() {
  const [auth, setAuth] = useState(false);
  console.log("auth", auth);
  let token = localStorage.getItem("token");

  const history = useHistory();
  const dispatch = useDispatch();

  useEffect(() => {
    const s1 = "myStrongJwtKey";
    if (token != null) {
      jwt.verify(token, `${s1}`, function (err, decode) {
        if (err) {
          localStorage.removeItem("token");
          setAuth(false);
          window.location.reload(false);
          console.log("eror whiel vefiying jwt");
          history.push("/login");
        } else {
          console.log("success jwt");
          setAuth(true);
          const decode = jwtDecode(token);
          dispatch(createUser(decode));
        }
      });
    }
  }, [auth]);
  return (
    <BrowserRouter>
      <Route path='/' exact component={Home} />
      <Route path='/about' exact component={About} />
      <Route path='/partners' exact component={Partners} />
      <Route path='/courses' exact component={Courses} />
      <Route path='/search/:id/:name' exact component={CoursesSearch} />
      <Route path='/course/:id/:name' exact component={CoursePreview} />
      <Route
        path='/:enrolled_id/:name/:course_id/subscribed/:id'
        exact
        component={SubscribedCourse}
      />
      <Route path='/start_course/:name/:id' exact component={StartCourse} />
      <Route path='/dashboard' exact component={Dashboard} />
      <Route path='/login' exact component={Login} />
      <Route path='/register' exact component={Register} />
      <Route path='/:user_id/demographics' exact component={Demographics} />
      <Route path='/videos' exact component={Videos} />
    </BrowserRouter>
  );
}

export default App;
