const express = require("express");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const auth = require("../config/auth");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "instructor_uploads");
  },
  filename: function (req, file, cb) {
    cb(
      null,
      file.fieldname + "_" + Date.now() + path.extname(file.originalname),
    );
  },
});
const upload = multer({ storage: storage });

const {
  createInstructor,
  fetchAllInstructor,
  fetchSingleInstructor,
  updateInstructor,
  deleteInstructor,
  fetchInstructorCourse
} = require("../Controllers/InstructorController");

router.post("/", upload.single("image"), createInstructor);
router.get("/", fetchAllInstructor);
router.get("/:id", fetchSingleInstructor);
router.put("/:id", updateInstructor);
router.delete("/", deleteInstructor);

router.get('/onCourse/:id',fetchInstructorCourse);

module.exports = router;
