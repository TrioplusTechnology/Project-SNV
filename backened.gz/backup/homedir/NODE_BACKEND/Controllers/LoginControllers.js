const LOGIN = require("../Models/Login");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcrypt");

function generateAccessToken(user) {
  return jwt.sign(user, process.env.SECRET_KEY, { expiresIn: "100800s" });
}
exports.registerValiations = [
  body("username").not().isEmpty().trim().withMessage("username is required")
];

exports.register = async (req, res) => {
  const { username,password } = req.body;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
     // Hash password
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
  try {
    let admin_login = new LOGIN(username, hash);
    
    logingin = await admin_login.create();
    // console.log("loggiiningin", logingin[0].affectedRows);
    const user={       
        username,
        hash
    }
    if (logingin.length >= 1) {
     const token = generateAccessToken(user);

      res.status(200).json({
        err: false,
        msg: "user created in successfully",
        token
        
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while registering your account",
      });
    }
  } catch (error) {
    return res.status(500).json({ errors: error });
  }
};

exports.getUsers = async (req, res, next) => {
  try {
    const [users] = await LOGIN.fetchAll();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};
exports.userLogin = async (req, res, next) => {
  try {
    let { username, password } = req.body;

    let [admin_login] = await new LOGIN().findUser(username);
    const res_user=admin_login[0];
    console.log(res_user);
    if (admin_login.length >= 1) {
      const matched = await bcrypt.compare(password, res_user.password);
      console.log(typeof matched);
      if (matched) {
        const token = generateAccessToken( res_user);
        return res
          .status(200)
          .json({ msg: "You have login successfully", token });
      } else {
        return res
          .status(401)
          .json({ errors: [{ msg: "Password is not correct" }] });
      }
    } else {
      return res.status(404).json({ errors: [{ msg: "user not found" }] });
    }
  } catch (error) {
    next(error);
  }
};
