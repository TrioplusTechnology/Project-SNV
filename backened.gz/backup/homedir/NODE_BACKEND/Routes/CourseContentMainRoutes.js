const express = require("express");
const router = express.Router();
const auth = require("../config/auth");

const {
  createCotentMainSection,
  fetchAllContentMainSection,
  deleteCourseContentMain,
  fetchSingleContentMainSection,
  updateContentMainSection,
  fetchSingleContentMainSectionOnCourse
} = require("../Controllers/ContentMainSectionController");

router.post("/", createCotentMainSection);
router.get("/", fetchAllContentMainSection);
router.get("/:id", fetchSingleContentMainSection);
router.put("/:id", updateContentMainSection);
router.delete("/:id", deleteCourseContentMain);

router.get('/onCourse/:id',fetchSingleContentMainSectionOnCourse);
module.exports = router;
