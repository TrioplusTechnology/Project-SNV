const express = require("express");
const router = express.Router();
const auth = require("../config/auth");



const {
  fetchAllUsers,
  fetchAllCourses,
  fetchAllEnrolledCourses,
  fetchAllSubContent,
} = require("../Controllers/StatisticsController");

router.get("/users", fetchAllUsers);
router.get('/courses',fetchAllCourses);
router.get('/enrolled',fetchAllEnrolledCourses);
router.get('/allSubContent/:id',fetchAllSubContent);

module.exports = router;
