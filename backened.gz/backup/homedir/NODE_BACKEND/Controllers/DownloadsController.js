const DOWNLOADS = require("../Models/CourseDownload");
const fs = require("fs");

exports.createDownloads = async (req, res, next) => {
  try {
    const { course_id, downloads } = req.body;
    const pdf = `${process.env.APP_HOSTING_ADDRESS + req.file.filename}`;

    let c_Downloads = new DOWNLOADS(
      course_id,
      pdf,
      downloads
    );
    result = await c_Downloads.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Course Download file has been added successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while adding Course Download file !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllCourseDownloads = async (req, res, next) => {
  try {
    const [downloads] = await DOWNLOADS.fetchAll();
    res.status(200).json(downloads.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleOnCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [download] = await DOWNLOADS.findById(id);
    res.status(200).json(download);
  } catch (error) {
    next(error);
  }
};

exports.updateDownloads = async (req, res, next) => {
  try {
    const id = req.params.id;
    const { downloads } = req.body;

    let u_download = await DOWNLOADS.updateDownloads(
      id,
     downloads
    );
    if (u_download[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Download Count updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating Download Count",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteDownloads = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { pdf } = req.body;

    fs.unlink(`./course_uploads/${pdf.split("/")[4]}`, function (err) {
      if (err) throw err;
      // if no error, file has been deleted successfully
      console.log("File deleted!");
    });

    let d_downloadFile = new DOWNLOADS(null);
    result = await d_downloadFile.deleteCourseDownload(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Course Download File deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting Course Download File !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
