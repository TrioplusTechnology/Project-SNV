const COURSE = require("../Models/Course");
const { body, validationResult } = require("express-validator");
const fs = require("fs");

exports.courseValiations = [
  body("category_id")
    .not()
    .isEmpty()
    .trim()
    .withMessage("category is required"),
];

exports.createCourse = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
    next(errors);
  }

  try {
    const {
      category_id,
      course_title,
      short_description,
      estimated_time,
      course_type,
      course_details,
      preview_video
    } = req.body;
    const image = `${process.env.APP_HOSTING_ADDRESS + req.file.filename}`;
    // priview video here is previouly used to be a file upload and now replaced with text field in front end of ppt embeddd link

    let c_Course = new COURSE(
      category_id,
      course_title,
      short_description,
      estimated_time,
      course_type,
      course_details,
      image,
      preview_video,
    );
    result = await c_Course.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Course has been created successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while creating course !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllCourse = async (req, res, next) => {
  try {
    const [categories] = await COURSE.fetchAll();
    res.status(200).json(categories.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchAllCourseOnCategory = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await COURSE.fetchCourseOnCategory(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};


exports.fetchSingleCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await COURSE.findById(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleCourseOnSubContent = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await COURSE.fetchSingleCourseOnFirstSubContent(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.fetchCoursesOnUser = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await COURSE.fetchCoursesOnUser(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.updateCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    const {
      category_id,
      course_title,
      short_description,
      estimated_time,
      course_type,
      course_details,
    } = req.body;

    let u_course = new COURSE(
      category_id,
      course_title,
      short_description,
      estimated_time,
      course_type,
      course_details,
    );
    result = await u_course.updateCourse(id);
    if (result[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Course updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating Course",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { image, video } = req.body;

    fs.unlink(`./course_uploads/${image.split("/")[4]}`, function (err) {
      if (err) throw err;
      // if no error, file has been deleted successfully
      console.log("File deleted!");
    });

    fs.unlink(`./course_uploads/${video.split("/")[4]}`, function (err) {
      if (err) throw err;
      // if no error, file has been deleted successfully
      console.log("File deleted!");
    });

    let d_course = new COURSE(null);
    result = await d_course.deleteCourse(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Course deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting Course !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
