const db = require("../config/db");
class VIDEOS {
  constructor(thumbnail, title, duration, link) {
    this.thumbnail = thumbnail;
    this.title = title;
    this.duration = duration;
    this.link = link;
  }
  create() {
    let createSql = `insert into videos (thumbnail,
title,
duration,
link) values ('${this.thumbnail}','${this.title}','${this.duration}','${this.link}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM videos;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM videos WHERE ID=${id}`);
  }

  updateVideos(id) {
    let updateSql = `UPDATE videos SET title='${this.title}', link='${this.link}',duration='${this.duration}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteVideos(id) {
    return db.execute(`DELETE FROM videos where id='${id}'`);
  }
}
module.exports = VIDEOS;
