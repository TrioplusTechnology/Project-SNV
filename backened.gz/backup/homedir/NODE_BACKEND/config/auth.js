const jwt = require("jsonwebtoken");
module.exports = (req, res, next) => {
  const authHeaders = req.headers.authorization;
  const token = authHeaders.split("Bearer")[0];
  console.log(authHeaders.split("Bearer"));
  try {
    jwt.verify(token, process.env.SECRET_KEY);
    next();
  } catch (error) {
    return res.status(401).json({ errors: [{ msg: error.message }] });
  }
};
