const db = require("../config/db");
class ENROLLED {
  constructor(user_id,course_id,redirection_link) {
    this.user_id=user_id;
    this.course_id=course_id;
    this.redirection_link=redirection_link;
  }
  create() {
    let createSql = `insert into enrolled_courses (user_id,course_id,redirection_link) values ('${this.user_id}','${this.course_id}','${this.redirection_link}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM enrolled_courses;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM enrolled_courses WHERE ID=${id}`);
  }
  
   static findByCourse(id) {
    return db.execute(`SELECT * FROM enrolled_courses WHERE course_id='${id}'`);
  }
  
    static findByUser(id) {
    return db.execute(`SELECT * FROM enrolled_courses WHERE user_id='${id}'`);
  }

  static updateLink(id,link) {
    let updateSql = `UPDATE enrolled_courses SET redirection_link='${link}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteEnrolled(id) {
    return db.execute(`DELETE FROM enrolled_courses where id='${id}'`);
  }
  //enrolled course
  //get latest enrolled id 
  static findLatestEnrolledCourse(){
      return db.execute(`select id from enrolled_courses order by id desc limit 1`);
  }
  static createProgress(enrolled_id,subsection_id){
      return db.execute(`INSERT INTO progress (enrolled_id,sub_section_id,checked) VALUES ('${enrolled_id}','${subsection_id}','false')`);
  }
  
  static deleteProgress(id){
      return db.execute(`DELETE FROM progress where enrolled_id='${id}'`);
  }
//   static fetchAllProgressOfUser(id){
//       return db.execute(`select * from progress where enrolled_id='${id}'`)
//   }
  
}
module.exports = ENROLLED;
