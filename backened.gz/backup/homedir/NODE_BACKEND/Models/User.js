const db = require("../config/db");
class USER {
  constructor(user_id, user_email, username, image,password) {
    this.user_id = user_id;
    this.user_email = user_email;
    this.username = username;
    this.image = image;
    this.password=password;
  }
  create() {
    let createSql = `insert into users (user_id, user_email, username, image,password) 
    values ('${this.user_id}','${this.user_email}','${this.username}','${this.image}','${this.password}')`;
    return db.execute(createSql);
  }

  static login(id) {
    let findSql = `SELECT * FROM users WHERE user_id='${id}'`;
    return db.execute(findSql);
  }

  static fetchAll() {
    let sql = "SELECT * FROM users;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM users WHERE user_id='${id}'`);
  }

  static findUser(email) {
    return db.execute(`SELECT * FROM users WHERE user_email='${email}' `);
  }
  
  deleteCourse(id) {
    return db.execute(`DELETE FROM users where user_id='${id}'`);
  }
}
module.exports = USER;
