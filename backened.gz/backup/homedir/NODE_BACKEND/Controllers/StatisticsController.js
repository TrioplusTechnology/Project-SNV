const STATISTICS = require("../Models/Statistics");

exports.fetchAllUsers = async (req, res, next) => {
  try {
    const [users] = await STATISTICS.fetchNoUsers();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

exports.fetchAllCourses = async (req, res, next) => {
  try {
    const [users] = await STATISTICS.fetchNoCourses();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

exports.fetchAllEnrolledCourses = async (req, res, next) => {
  try {
    const [users] = await STATISTICS.fetchNoEnrolledCourses();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

exports.fetchAllSubContent = async (req, res, next) => {
  const id = req.params.id;
  try {
    const [total] = await STATISTICS.fetchTotalContentNo(id);
    res.status(200).json(total);
  } catch (error) {
    next(error);
  }
};
