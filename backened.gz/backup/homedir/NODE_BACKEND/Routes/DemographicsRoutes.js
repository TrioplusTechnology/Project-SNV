const express = require("express");
const auth = require("../config/auth");
const router = express.Router();

const {
  demographicsValiations,
  createDemographics,
  fetchAllDemographics,
  fetchSingleDemographics,
  updateDemographics,
  deleteDemographics,
} = require("../Controllers/DemographicsController");

router.post("/", demographicsValiations,createDemographics);
router.get("/", fetchAllDemographics);
router.get("/:id", fetchSingleDemographics);
router.put("/:id", updateDemographics);
router.delete("/:id", deleteDemographics);

module.exports = router;
