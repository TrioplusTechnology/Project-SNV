const CONTENTMAINSECTION = require("../Models/ContentMainSection");
const { body, validationResult } = require("express-validator");
const fs = require("fs");

exports.contentMainSectionValiations = [
  body("course_id").not().isEmpty().trim().withMessage("category is required"),

  body("section_title")
    .not()
    .isEmpty()
    .trim()
    .withMessage("section title is required"),

  body("section_time")
    .not()
    .isEmpty()
    .trim()
    .withMessage("section time is required"),
];

exports.createCotentMainSection = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { course_id, section_title, section_time } = req.body;

    let c_Content_main_section = new CONTENTMAINSECTION(
      course_id,
      section_title,
      section_time,
    );
    result = await c_Content_main_section.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Course content for main section has been added successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "error while adding course content for main section !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllContentMainSection = async (req, res, next) => {
  try {
    const [content_main] = await CONTENTMAINSECTION.fetchAll();
    res.status(200).json(content_main.reverse());
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleContentMainSection = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await CONTENTMAINSECTION.findById(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.fetchSingleContentMainSectionOnCourse = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [course] = await CONTENTMAINSECTION.findByCourse(id);
    res.status(200).json(course);
  } catch (error) {
    next(error);
  }
};

exports.updateContentMainSection = async (req, res, next) => {
  try {
    const id = req.params.id;
    const { course_id, section_title, section_time } = req.body;

    let u_course = new CONTENTMAINSECTION(
      course_id,
      section_title,
      section_time,
    );
    result = await u_course.update(id);
    if (result[0].affectedRows === 1) {
      res.status(200).json({
        err: false,
        msg: "Course content --main updated successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while updating Course content --main",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteCourseContentMain = async (req, res, next) => {
  try {
    const id = req.params.id;

    let d_course = new CONTENTMAINSECTION(null);
    result = await d_course.delete(id);
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "CONTENTMAINSECTION deleted successfully !",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while deleting CONTENTMAINSECTION !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    next(error);
  }
};
