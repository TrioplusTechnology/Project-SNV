const express = require("express");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const auth = require("../config/auth");

// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, "course_content_uploads");
//   },
//   filename: function (req, file, cb) {
//     cb(
//       null,
//       file.fieldname + "_" + Date.now() + path.extname(file.originalname),
//     );
//   },
// });
// const upload = multer({ storage: storage });

const {
  createContentSubSection,
  fetchAllContentSubSection,
  fetchSingleContentSubSection,
  updateContentSubSection,
  deleteCourseContentSub,
  fetchSingleContentSubSectionOnSection
//   fetchLearningMaterialContentSubSection
} = require("../Controllers/ContentSubSectionController");

router.post("/",  createContentSubSection);
router.get("/", fetchAllContentSubSection);
router.get("/:id", fetchSingleContentSubSection);
router.put("/:id", updateContentSubSection);
router.delete("/", deleteCourseContentSub);

router.get('/onSection/:id',fetchSingleContentSubSectionOnSection);
// router.get('/learningMaterial/:id',fetchLearningMaterialContentSubSection);

module.exports = router;
