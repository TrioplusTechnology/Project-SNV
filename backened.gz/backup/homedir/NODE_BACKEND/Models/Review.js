const db = require("../config/db");
class REVIEW {
  constructor(course_id,user_id,stars,review_message) {
    this.course_id=course_id;
    this.user_id=user_id;
    this.stars=stars;
    this.review_message=review_message;
  }
  create() {
    let createSql = `insert into review (course_id,user_id,stars,review_message) values ('${this.course_id}','${this.user_id}','${this.stars}','${this.review_message}')`;
    return db.execute(createSql);
  }

  static fetchAllReviewOnCourse(id){
      return db.execute(`select review.id,review.stars,review.review_message,users.username,users.image from review inner join users on review.user_id=users.user_id where course_id='${id}' order by id desc`)
  }
  
  static fetchAvgRating(id){
      return db.execute(`select avg(stars) as avg from review where course_id='${id}'`)
  }
  
//     static updateChecked(id,checked,enrolled_id){
//       return db.execute(`update progress set checked='${checked}' where sub_section_id='${id}' && enrolled_id='${enrolled_id}'`)
//   }
  
}
module.exports = REVIEW;
