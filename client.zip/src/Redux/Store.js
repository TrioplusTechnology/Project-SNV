import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./user/UserSlice";
import courseReducer from "./course/CourseInfoSlice";

export const Store = configureStore({
  reducer: {
    user: userReducer,
    course: courseReducer,
  },
});
