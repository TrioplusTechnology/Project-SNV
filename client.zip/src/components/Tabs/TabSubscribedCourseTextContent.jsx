import axios from "axios";
import { useEffect, useState } from "react";
import MasterLoading from "../LoadingSpinners/MasterLoading";

function TabSubscribedCourseTextContent({id}) {
    const [data,setData]=useState([]);
    const [loading,setLoading]=useState(false);

    useEffect(() => {
        const fetch=async()=>{
            try {
                setLoading(true);
                await axios.get(`${process.env.REACT_APP_URL}/course/section/sub/${id}`).then(res=>{
                 setData(res.data);
                 setLoading(false)
             })
                
            } catch (error) {
                console.error(error);
            }
        }
        fetch()
     }, [id])
    return (
        <div>
            {loading&&<MasterLoading />}
            {data.map(item=>(
                <div dangerouslySetInnerHTML={{__html:item.text_content}} className="my-4 text-lg leading-9"></div>
            ))}
        </div>
    )
}

export default TabSubscribedCourseTextContent
