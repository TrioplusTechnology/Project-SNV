const express = require("express");
const router = express.Router();

const {
  registerValiations,
  register,
  userLogin,
  getUsers
} = require("../Controllers/LoginControllers");
router.get("/", getUsers);
router.post("/register", register);
router.post("/", userLogin);
//   router.put("/:id", userUpdate);

module.exports = router;
