const PROGRESS = require("../Models/Progress");


exports.createProgress = async (req, res, next) => {
  
  try {
    const { enrolled_id,sub_section_id,checked } = req.body;
    let c_Progress = new PROGRESS(enrolled_id,sub_section_id,checked );
    result = await c_Progress.create();
    if (parseInt(result[0].affectedRows) === 1) {
      res.status(200).json({
        err: false,
        msg: "Data has been added to your progress successfully!",
      });
    } else {
      res.status(401).json({
        err: true,
        msg: "Error while adding data to your progress !",
        actErr: result[0].info,
      });
    }
  } catch (error) {
    console.error(error);
  }
};

exports.fetchAllProgress = async (req, res, next) => {
    const id = req.params.id;
    try {
    const [progress] = await PROGRESS.fetchAllProgressOfUser(id);
    res.status(200).json(progress);
  } catch (error) {
    next(error);
  }
};

exports.updateProgressCheck = async (req, res, next) => {
    
    const {sub_section_id,checked,enrolled_id}=req.body
    try {
    const [progress] = await PROGRESS.updateChecked(sub_section_id,checked,enrolled_id);
    if (progress.affectedRows === 1) {
        res.status(200).json({
          err: false,
          msg: "Progress check updated successfully !",
        });
      } else {
        res.status(401).json({
          err: true,
          msg: "Error while updating progress check",
          actErr: result[0].info,
        });
      }
    res.status(200).json(progress);
  } catch (error) {
    next(error);
  }
};

