const db = require("../config/db");
class CONTENTMAINSECTION {
  constructor(course_id, section_title, section_time) {
    this.course_id = course_id;
    this.section_title = section_title;
    this.section_time = section_time;
  }
  create() {
    let createSql = `insert into content_main_section (course_id,section_title,section_time) 
    values ('${this.course_id}','${this.section_title}','${this.section_time}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM content_main_section;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM content_main_section WHERE ID=${id}`);
  }
  
  static findByCourse(id){
    return db.execute(`SELECT * FROM content_main_section WHERE course_id=${id}`);
  }

  update(id) {
    let updateSql = `UPDATE content_main_section SET section_title='${this.section_title}', section_time='${this.section_time}' where id='${id}';`;
    return db.execute(updateSql);
  }
  delete(id) {
    return db.execute(`DELETE FROM content_main_section where id='${id}'`);
  }
}
module.exports = CONTENTMAINSECTION;
