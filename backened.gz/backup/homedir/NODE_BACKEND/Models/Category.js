const db = require("../config/db");
class CATEGORY {
  constructor(category) {
    this.category = category;
  }
  create() {
    let createSql = `insert into course_category (category) values ('${this.category}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM course_category;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM course_category WHERE ID=${id}`);
  }

  updateCategory(id) {
    let updateSql = `UPDATE course_category SET category='${this.category}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteCategory(id) {
    return db.execute(`DELETE FROM course_category where id='${id}'`);
  }
}
module.exports = CATEGORY;
