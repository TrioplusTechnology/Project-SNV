import React from 'react'

function ErrorPage() {
    return (
        <div>
            <h1>You are not allowed to visit this</h1>
        </div>
    )
}

export default ErrorPage
