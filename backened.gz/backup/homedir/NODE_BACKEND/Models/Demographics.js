const db = require("../config/db");
class DEMOGRAPHICS {
  constructor(user_sub_id,gender,age,district,registration_date) {
    this.user_sub_id=user_sub_id;
    this.gender=gender;
    this.age=age;
    this.district=district;
    this.registration_date=registration_date;
  }
  create() {
    let createSql = `insert into user_demographics (user_sub_id,gender,age,district,registration_date) 
    values ('${this.user_sub_id}','${this.gender}','${this.age}','${this.district}','${this.registration_date}')`;
    return db.execute(createSql);
  }
  static fetchAll() {
    let sql = "SELECT * FROM user_demographics;";
    return db.execute(sql);
  }
  static findById(id) {
    return db.execute(`SELECT * FROM user_demographics WHERE ID=${id}`);
  }

  updateUserDemographics(id) {
    let updateSql = `UPDATE user_demographics SET gender='${this.gender}', age='${this.age}','${this.district}' where id='${id}';`;
    return db.execute(updateSql);
  }
  deleteDemographics(id) {
    return db.execute(`DELETE FROM user_demographics where id='${id}'`);
  }
}
module.exports = DEMOGRAPHICS;
