require("dotenv").config();

const express=require('express');
const cors =require('cors');
const path = require( "path" );
const app =express();
app.use(cors());

// middlewares 
// app.use(express.json()); //parse json bodies into the request object
app.use(express.json({limit: '50mb'}));
app.use(express.urlencoded({limit: '50mb'}));

// routes
app.get('/',async(req,res)=>{
    await res.send('hello')
})

app.use("/category", require("./Routes/CategoryRoutes"));
app.use("/course", require("./Routes/CourseRoute"));
app.use("/course/section/main", require("./Routes/CourseContentMainRoutes"));
app.use("/course/section/sub", require("./Routes/CourseContentSubRoutes"));
app.use("/instructor", require("./Routes/InstructorRoutes"));
app.use("/user", require("./Routes/UserRoutes"));
app.use('/enrolled',require('./Routes/EnrolledCourseRoutes'));
app.use('/statistics',require('./Routes/StatisticsRoutes'));
app.use('/progress',require('./Routes/ProgressRoutes'));
app.use('/review',require('./Routes/ReviewRoutes'));
app.use('/demographics',require('./Routes/DemographicsRoutes'));
app.use('/login',require('./Routes/LoginRoutes'));
app.use('/videos',require('./Routes/VideosRoutes'));
app.use('/courseDownload',require('./Routes/DownloadsRoutes'));

// app.use('/google',require('./Routes/GoogleLoginRoutes'));

// app.use("/dashboard_login", require("./Routes/LoginRoutes"));

// route for image 
app.use('/', express.static(path.join(__dirname, '/')));

// // Handle React routing, return all requests to React app
//   app.get('/', function(req, res) {
//     res.sendFile(path.join(__dirname, '/', 'index.html'));
//   });

app.use((err,req,res,next)=>{
    console.log(err.stack);
    console.log(err.name);
    console.log(err.code);

    res.status(500).json({
        err:'true',
        message:'something went wrong',
        err
    });
});

// listen on pc port 
const PORT =process.env.PORT || 4000;
app.listen(PORT,()=>console.log(`Sever running on port ${PORT}`));