const express = require("express");
const multer = require("multer");
const router = express.Router();
const auth = require("../config/auth");
const path = require("path");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "course_uploads");
  },
  filename: function (req, file, cb) {
    cb(
      null,
      file.fieldname + "_" + Date.now() + path.extname(file.originalname),
    );
  },
});
const upload = multer({ storage: storage });

const {
  createCourse,
  fetchAllCourse,
  deleteCourse,
  fetchSingleCourse,
  updateCourse,
  fetchAllCourseOnCategory,
  fetchSingleCourseOnSubContent,
  fetchCoursesOnUser
} = require("../Controllers/CourseController");

router.post("/", upload.single("image"), createCourse);
router.get("/", fetchAllCourse);
router.get("/:id", fetchSingleCourse);
router.put("/:id", updateCourse);
router.delete("/:id", deleteCourse);

router.get("/category/:id", fetchAllCourseOnCategory);
router.get('/subcontent/first/:id',fetchSingleCourseOnSubContent);
router.get('/onUser/:id',fetchCoursesOnUser);


module.exports = router;
