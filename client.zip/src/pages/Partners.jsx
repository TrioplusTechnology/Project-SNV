import React from 'react'
import Page from '../templates/Page'

function Partners() {
    return (
        <Page>
             <div className="container mx-auto px-4 lg:px-6">
                Partners
            </div>
        </Page>
    )
}

export default Partners
